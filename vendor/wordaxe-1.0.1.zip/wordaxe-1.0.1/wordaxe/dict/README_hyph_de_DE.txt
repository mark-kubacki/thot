Hyphenation dictionary
----------------------

Language: German (de DE).
Origin:   Based on the TeX hyphenation tables
          http://www.tug.org/tex-archive/language/hyphenation/dehyphn.tex
License:  GNU LGPL license.
Author:   conversion author is Marco Huggenberger<marco@by-night.ch>
          revised conversion and extensions: Daniel Naber
          http://qa.openoffice.org/issues/show_bug.cgi?id=26355

Please note, this dictionary is based on syllable matching patterns
and thus should be suitable under other variations of German

HYPH de DE hyph_de_DE
HYPH de CH hyph_de_CH

--------------------------------------------------------------------------------
Trennmuster (hyph_de_DE.dic):
--------------------------------------------------------------------------------

Die Trennmuster (hyph_de_DE.dic) basieren auf den TeX Trennmustern
"dehyphn.tex", revision level 31.
Lizenz der Trennmuster: GNU LGPL. Die Anpassung der Trennmuster an
den in OpenOffice.org benutzten "ALTLinux LibHnj Hyphenator" wurde
mit dem Script substrings.pl durchgef�hrt, das unter
http://lingucomponent.openoffice.org/hyphenator.html als Teil der
Datei altlinux_Hyph.zip heruntergeladen werden kann.
Die Original-Trennmuster k�nnen hier heruntergeladen werden:
http://www.tug.org/tex-archive/language/hyphenation/dehyphn.tex
