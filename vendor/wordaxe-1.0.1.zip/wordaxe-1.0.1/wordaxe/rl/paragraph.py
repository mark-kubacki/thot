#!/bin/env python
# -*- coding: iso-8859-1 -*-
#Copyright ReportLab Europe Ltd. 2000-2004
#
#see license.txt for license details
#history http://www.reportlab.co.uk/cgi-bin/viewcvs.cgi/public/reportlab/trunk/platypus/paragraph.py
#$Header: /cvsroot/deco-cow/hyphenation/reportlab/platypus/paragraph.py,v 1.1.1.1 2004/04/27 21:19:02 hvbargen Exp $
#
# @CHANGED Henning von Bargen, added hyphenation support.

from wordaxe.rl.NewParagraph import *
